KAFELA Islamic Foundation website

1. Open index.html in a browser to preview.
2. To publish: sign in to Netlify, choose Add new site > Deploy manually, and upload this folder (or a ZIP of its contents).
3. Volunteer Google Form is intentionally NOT connected yet. The form submit button stays disabled until configured.
4. To connect Google Forms, create a Google Form, obtain its formResponse URL and each field's entry ID, then update GOOGLE_FORM_ACTION and the corresponding input name attributes in index.html. Test with non-sensitive sample data first.
5. Replace contact placeholders only with verified official contact details.
